# Assignment 2, AOS, Autumn 2023
## Group Details
1. Pranav Mehrotra, 20CS10085
2. Saransh Sharma, 20CS30065
